import os
import subprocess
import yaml
import pandas as pd
import re
import datetime


def _get_exception(errorMessage):
    """helper function which extracts the raised error from the error Message. Used by list_() method"""
    tmp = re.search("(?:Exception|Error): (.*)", errorMessage)
    if tmp:
        return tmp.group(1)
    else:
        return ""

def list_(**options):
    """Lists AI jobs (both running and finished) 
    Appends the error column for easier filtering
    Input:
        options to be passed to gclosu ai-platform jobs list command
          do not use the format and is it implied for the transformations!
          for 'filter' the quotation marks may need to be included explicitely in the string like filter='"conditions"'
    Returns:
        dataframe with AI Jobs parameters
    """
    arguments = " ".join([f"--{key}={value}" for key, value in options.items()])
    jobs_yaml = subprocess.check_output(f"gcloud ai-platform jobs list {arguments} --format='yaml'", shell=True, universal_newlines=True)
    jobs_generator=yaml.safe_load_all(jobs_yaml)
    ret = pd.DataFrame(list(jobs_generator))
    if 'errorMessage' in ret.columns:
        ret['error']=ret.errorMessage.dropna().transform(_get_exception)
    return ret

def bq_tables(client, project, dataset):
    """Returns a dataframe with BQ tables
    Arguments:
        client - BW client
        project - project name
        dataset - dataset from which tables are to be listed
    """
    return client.query(f"SELECT * FROM `{project}.{dataset}.INFORMATION_SCHEMA.TABLES`").to_dataframe()

def submit_training(job_name, dry_run=False, **options):
    """
    Wrapper for running ai jobs using the gcloud command. 
    gcloud is more reliant and flexible than the API and creates python packages (needed to set up the AI Jobs instance) automatically.
    
    job_name - name of the job (timestamp-like integer will be attached to make it uniqueness)
    dry_run - if set to True prints the gcloud command instead of executing it
    options - commands passed to gcloud ai-platform jobs submit training in the form of python keyword arguments (typically module-name and package-path are necessary)
        default options (adapted for chargeable demand prediction project):
            "staging-bucket":"gs://prd-9375-chargdemand-ds-staging",
            "job-dir":f"gs://prd-9375-chargdemand-ds-pkgs/{job_name_timestamp}",
            "python-version":"3.7",
            "runtime-version":"2.2",
            "region":"us-central1",
            "scale-tier":"BASIC"
            
    returns the gcloud return value or None for dry_run==True
    """
    
    timestamp = datetime.datetime.utcnow().strftime("%y%m%d%H%M%S%f")  # just to make every job name unique
    job_name_timestamp = job_name + '_' + timestamp
    
    job_submission_cmd = f'gcloud ai-platform jobs submit training "{job_name_timestamp}"  '
        
    default_options={"staging-bucket":"gs://prd-9375-chargdemand-ds-staging",
            "job-dir":f"gs://prd-9375-chargdemand-ds-pkgs/{job_name_timestamp}",
            "python-version":"3.7",
            "runtime-version":"2.2",
            "region":"us-central1",
            "scale-tier":"BASIC"}

    options_all = {**default_options, **options}
        
    job_submission_cmd += " ".join([f"--{key}={value}" for key, value in options_all.items()])
    if dry_run:
        print(job_submission_cmd)   
    else:
        return os.system(job_submission_cmd)
    
