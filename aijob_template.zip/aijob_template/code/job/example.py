# the code must be located in code/job/ directory


#############################################
#### Identification of the working directory
#### Needed for accessing the other files through direct paths

import os
jobdir = os.path.dirname(os.path.realpath(__file__))
print('jobdir',jobdir)

#############################################

#### The rest of the code can be addapted for the needs
#  read libraries relative to the code directory not the script working directory
from library1.example_module import example_func



def main():

    # loading the config file (path needs to be absolute)
    with open(jobdir+'/config.yml','r') as _f:
        config = yaml.safe_load(_f)

    # You can use prints for you logging messages
    print("This message will appear as a INFO level log in AI Jobs logging information")
    
    # Write results to BQ or GCS. All files and temporary results will be lost at the end of the job!!!

    
if __name__ == '__main__':
    main()
