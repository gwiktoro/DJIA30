# import pandas as pd
# # from gstudio import bq
# from datetime import datetime
# from google.cloud import bigquery
# import job.config as conf
# import tmp.func as func
# import cdplib.poc_queries as queries

# cfg = conf.Configuration("config.yml").getConfig()
# bq_gcpprojectid = cfg['bq']['project']
# bq_datasetname = cfg['bq']['dataset']  
# bq_tablename = cfg['bq']['project'] + "." + cfg['bq']['dataset'] + "." + cfg['bq']['tablename']
# bq_word = cfg['bq']['word']

# schema=[
#     bigquery.SchemaField("word", bigquery.enums.SqlTypeNames.STRING),
#     bigquery.SchemaField("count", bigquery.enums.SqlTypeNames.FLOAT),
# ]

# df = pd.DataFrame([
#     {'count':1.2, 'word': bq_word}
# ])
import os
jobdir = os.path.dirname(os.path.realpath(__file__))
print('jobdir',jobdir)

exec(open(jobdir+"/../cdplib/poc_imports.py",'r').read())


# bq.load(bq_gcpprojectid, bq_datasetname , bq_tablename, schema, df, "WRITE_APPEND")
client = bigquery.Client()

from cdplib.variable_similarity import get_related_noninv_vars, remove_coint_exog_vars
from cdplib import poc_functions
from cdplib import poc_queries
from cdplib.poc_variables import LB, Availability, OOD, OM, relevant_variables

import yaml
with open(jobdir+'/dataprep.yml','r') as _f:
    config = yaml.safe_load(_f)

with open(jobdir+'/intersections.yml','r') as _f:
    intersections = yaml.safe_load(_f)


INTERSECTION_NAME = config['intersection']
intersection_sql_query = intersections[INTERSECTION_NAME]['intersection_sql_query']

PROJECT = config['PROJECT']
DATASET = config["DATASET"]
allow_temp_BQ_tables_write = config["allow_temp_BQ_tables_write"] # set to True if you are preprocessing files, otherwise leave as False to avoid overwriting existing tables
target = config['target']
use_gcp_filter = config["use_gcp_filter"]  

countries_query = """SELECT distinct(country_territory) FROM `prd-65343-datalake-bd-88394358.hrdemandforecast_9375_ds.mapping_monthpermonth_202103` where {}"""

countries = client.query(countries_query.format(intersection_sql_query)).to_dataframe()

country_list = list(countries["country_territory"].dropna())
countries_fix = []
for country in country_list:
    countries_fix.append("'"+country+"'")
countries = "(" + ','.join(countries_fix) + ")"


months_mappings = pd.to_datetime(pd.date_range('2020-03-01','2021-03-01', freq='MS')).strftime("%Y%m").tolist()
print(f"months_mappings: {months_mappings}")
preds_months = pd.to_datetime(pd.date_range('2020-03-01','2021-02-01', freq='MS')).strftime("%Y-%m").tolist()
print(f"preds_months: {preds_months}")

if use_gcp_filter:
    gcp_filter = poc_queries.gcp_filter
else:
    gcp_filter = ""


# BQ tablenames fot the main 3 data sources that we are using for modelling 
LB_table = f"{PROJECT}.{DATASET}.LB_Data"
avail_table = f"{PROJECT}.{DATASET}.Availability"
ood_table = f"{PROJECT}.{DATASET}.OOD"

def safe_write_to_bqtable(dl, table_name, disposition_type):
    """ wrapper around bqhelper.write_to_bqtable which helps to avoid unintentional overwriting existing tables
        depends on the value of allow_temp_BQ_tables_write flag
    """
    write_ = False
    try:
        client.get_table(table_name)
        if allow_temp_BQ_tables_write:
            write_ = True
    except:
        write_ = True

    if write_:
        job = client.load_table_from_dataframe(df,
                                               table_name, 
                                               job_config=bigquery.LoadJobConfig(write_disposition="WRITE_TRUNCATE"))
        print(f"Table {table_name} has been written")

print('setup completed') 

# Preprocessing the data
df_g_list = []
for month in months_mappings[:1]:
    print(f"month: {month}")

    mapping_table_id = f"{PROJECT}.{DATASET}.mapping_monthpermonth_{month}"

    #print(query_roster_LB.format(mapping_table_id, intersection_sql_query, gcp_filter, avail_table, LB_table))

    df = client.query(poc_queries.query_roster_LB.format(mapping_table_id, intersection_sql_query, gcp_filter, avail_table, LB_table)).to_dataframe()
    df['Date'] = pd.to_datetime(df['yearmonth'].astype(str), format='%Y%m').dt.tz_localize(None)
    df.drop(columns=["Current_Calendar_Project_ID","Employee_ID","yearmonth_LB"],inplace=True)

    df, relevant_avail_variables = poc_functions.create_avail_variables(df)
    df,LB_FTE = poc_functions.create_LB_variables(df)

    # Filter unreliable data

    df_ood = client.query(poc_queries.query_ood.format(ood_table=ood_table, countries=countries, intersection_sql_query=intersection_sql_query, mapping_table_id=mapping_table_id )).to_dataframe()
    df_grouped_ood, relevant_ood_variables = poc_functions.preprocess_ood(df_ood)

    # Group data per month
    aggr_levels = ["Date", "yearmonth"]
    df_grouped = df[aggr_levels+["Chargeable_FTE"]+LB_FTE+relevant_avail_variables].groupby(by=aggr_levels).sum().reset_index()
    # YM file
    # YM file
    df_grouped = df_grouped.merge(df_grouped_ood, how="left", on=["Date", "yearmonth"])
    df_grouped["mapping_yearmonth"] = int(month)

    # Add to list
    df_g_list += [df_grouped]

df_grouped_final = pd.concat(df_g_list).reset_index(drop=True)

print('df_grouped_final created')

# ADDING COVID related variables (potentially useful)
df_grouped_final["Lockdown"] = ~((df_grouped_final['Date']<"2020-04")+(df_grouped_final['Date']>"2020-07")) * 1
# df_grouped_final

# GW
# Reading OM data and appending to df_grouped_final

om_data=pd.DataFrame()
for mapping_yearmonth in [int(month.replace('-','')) for month in preds_months][:1]:
    print(f"mapping_yearmonth: {mapping_yearmonth}")
    tmp = client.query(f"SELECT * from {PROJECT}.{DATASET}.LB_OM_{mapping_yearmonth} where {intersection_sql_query}").to_dataframe()
    om_data = om_data.append(tmp[['yearmonth'] + [col for col in tmp.columns if np.any([x in col for x in ['revenue','work_hours']])]]
                             .groupby('yearmonth')
                             .sum()
                             .sort_values('yearmonth')
                             .assign(mapping_yearmonth=mapping_yearmonth))

om_data.reset_index(inplace=True)
OM = [col for col in om_data.columns if np.any([x in col for x in ['revenue','work_hours']])]
df_grouped_final_copy = df_grouped_final.copy()
df_grouped_final = df_grouped_final.merge(om_data, on=['yearmonth','mapping_yearmonth'])
# df_grouped_final

# Writes table to BQ if allow_temp_BQ_tables_write or table does not exist
table_name = f"{PROJECT}.{DATASET}.df_grouped_{INTERSECTION_NAME}_LB_AVAIL_OOD"

safe_write_to_bqtable(df_grouped_final, table_name ,disposition_type = 'WRITE_TRUNCATE')
