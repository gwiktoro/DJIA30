from setuptools import find_packages
from setuptools import setup

REQUIRED_PACKAGES = ['google-cloud-bigquery', 'google-cloud-bigquery-storage','scikit-learn>=0.24','numpy==1.19.5','pandas','pmdarima']

setup(
  name='chargeable-demand-train-package',
  version='0.1',
  install_requires=REQUIRED_PACKAGES,
  packages=find_packages(),
  description='A deployment package for training on Cloud ML Engine.',
#  scripts = ['job/main.py','job/config.yml','job/config.py',] , #'job/bq.py' # This is not necessary
  package_data = {'job' : ["*.yml", "job/*"] }  # this is necessary
)