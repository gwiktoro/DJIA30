gcp_filter = f"""
                and (Org_Level_2_Name_orig is null or Org_Level_2_Name_orig not like "%GCP%")
                and (Org_Level_3_Name_orig is null or Org_Level_3_Name_orig not like "%GCP%")
                and (Org_Level_4_Name_orig is null or Org_Level_4_Name_orig not like "%GCP%")
                and (Org_Level_5_Name_orig is null or Org_Level_5_Name_orig not like "%GCP%")
                and (Org_Level_6_Name_orig is null or Org_Level_6_Name_orig not like "%GCP%")
                and (Org_Level_3_Name_assigned is null or Org_Level_3_Name_assigned not like "%GCP%")
                and (Org_Level_4_Name_assigned is null or Org_Level_4_Name_assigned not like "%GCP%")
                and (Org_Level_5_Name_assigned is null or Org_Level_5_Name_assigned not like "%GCP%")
                and (Org_Level_6_Name_assigned is null or Org_Level_6_Name_assigned not like "%GCP%")
             """
    
    
# We use the LB, mapping and availability tables to create the history for each intersection. 
# Every month post NGGM we have to use the mapping. 
# The variables from LB are aggregated per employee code and yearmonth in order to only have a record per employee and month. 
query_roster_LB = """SELECT *
FROM 
    (SELECT mapping.employee_code, mapping.yearmonth, avail.Availability_Status, avail.Availability_Detail, avail.Now_Available_Category, avail.Coming_Available, 
            avail.First_Available_Date, avail.Current_Calendar_Entry, avail.Current_Calendar_Project_ID, avail.Current_Project_Is_Chargeable, 
            avail.Current_Calendar_Start_Date, avail.Current_Calendar_End_Date, avail.Current_Calendar_Roll_Off_Confirmed, avail.Current_Calendar_Roll_Off_Confirmed_Date
    FROM
        (SELECT distinct employee_code, yearmonth FROM `{}`
        WHERE {} {}) mapping
        LEFT JOIN 
        (SELECT * FROM {}) avail
        ON mapping.employee_code=avail.employee_code and mapping.yearmonth=avail.yearmonth
    ) aaa
    INNER JOIN 
    (SELECT Employee_ID,sum(Chrg_Time_Total) Chrg_Time_Total,sum(Chrg_Time_Total_FTEs) Chrg_Time_Total_FTEs,
sum(Non_Chrg_Time_APA) Non_Chrg_Time_APA,sum(Non_Chrg_Time_Bus_Dev) Non_Chrg_Time_Bus_Dev,sum(Non_Chrg_Time_Cap_Infra_Dev) Non_Chrg_Time_Cap_Infra_Dev,
sum(Non_Chrg_Time_M_O) Non_Chrg_Time_M_O,sum(Non_Chrg_Time_Mrkt_Dev_and_Off_Dev_Main) Non_Chrg_Time_Mrkt_Dev_and_Off_Dev_Main,sum(Non_Chrg_Time_Prof_Dev_Recr) Non_Chrg_Time_Prof_Dev_Recr,
sum(Non_Chrg_Time_Susp_Unassign) Non_Chrg_Time_Susp_Unassign,sum(Non_Chrg_Time_Total) Non_Chrg_Time_Total,sum(Total_Reported_Time) Total_Reported_Time,yearmonth as yearmonth_LB FROM `{}` group by Employee_ID,yearmonth) aa
    ON aaa.employee_code=aa.Employee_ID and aaa.yearmonth = aa.yearmonth_LB
"""


# The OOD also needs to be mapped. 
# The demand comes with the Fulfillment Entity associated, 
# it matches with the Org Level and the problem is that the name org level changes with the mapping (meaning that pre NGGM we have to assign the match. 
# Each row in OOD means that an employee is required per task, so the number of row per project is the number of employees demanded.
# What we do here is check the demand in the countries that belong to the intersection and check the percentage that is within our desired intersection.

query_ood = """SELECT  Project_ID, Project_Country, Service_Group, Project_Is_Sold, Win_Probability, Project_Is_Chargeable, Project_Client_Contract_Based, Common_Demand_ID, Assignment_ID, 
        Role_is_Sold, Role_Sold_Pct, Role_is_Chargeable, Role_Client_Contract_Based, Role_is_Overdue, Number_of_Days_Overdue, Coming_Overdue_Within_7_Days, Role_is_Past_Start_Date, 
        Number_of_Days_Past_Start_Date, Role_is_Past_Fulfillment_Date, Days_Past_Fulfillment_Date, Status, Role_Country, Role_Metro_City, Fulfillment_Entity_L1, Fulfillment_Entity_L2, 
        Fulfillment_Entity_L3, Fulfillment_Entity_L4, Fulfillment_Entity_L5, Fulfillment_Entity_L6, Role_Priority, Role_Start_Date, Role_Start_Month, Expected_Fulfillment_Date, Role_End_Date, Create_Date, 
        Role_Bill_Code_From, Role_Bill_Code_To, Last_Update_Date, Source, Role_is_GCP, Project_Start_Date, Project_End_Date, Project_Opportunity_ID, aa.yearmonth,
        sum(total) as total, 
        sum(num_intersection) as num_intersection,
        sum(num_intersection)/sum(total) as pct_intersection, 
FROM
    (SELECT *, concat(Fulfillment_Entity_L1, Fulfillment_Entity_L2, Fulfillment_Entity_L3, Fulfillment_Entity_L4, Fulfillment_Entity_L5, Fulfillment_Entity_L6) as Fulfillment_Label
    FROM `{ood_table}` WHERE Role_Country in {countries}
    ) aa
    INNER JOIN 
    (SELECT yearmonth, Org_Level_1_Name_orig, Org_Level_2_Name_orig, Org_Level_3_Name_orig, Org_Level_4_Name_orig, Org_Level_5_Name_orig, Org_Level_6_Name_orig, count(*) as total, 
            sum(CASE WHEN assigned_country in {countries} and {intersection_sql_query} THEN 1 ELSE 0 END) as num_intersection
    FROM `{mapping_table_id}` WHERE country_territory in {countries}
    GROUP BY yearmonth, Org_Level_1_Name_orig, Org_Level_2_Name_orig, Org_Level_3_Name_orig, Org_Level_4_Name_orig, Org_Level_5_Name_orig, Org_Level_6_Name_orig 
    ) bb
    ON aa.yearmonth=bb.yearmonth and aa.Fulfillment_Entity_L1=bb.Org_Level_1_Name_orig
    and (aa.Fulfillment_Entity_L2=bb.Org_Level_2_Name_orig OR (aa.Fulfillment_Entity_L2 is NULL))
    and (aa.Fulfillment_Entity_L3=bb.Org_Level_3_Name_orig OR (aa.Fulfillment_Entity_L3 is NULL))
    and (aa.Fulfillment_Entity_L4=bb.Org_Level_4_Name_orig OR (aa.Fulfillment_Entity_L4 is NULL))
    and (aa.Fulfillment_Entity_L5=bb.Org_Level_5_Name_orig OR (aa.Fulfillment_Entity_L5 is NULL))
    and (aa.Fulfillment_Entity_L6=bb.Org_Level_6_Name_orig OR (aa.Fulfillment_Entity_L6 is NULL))
GROUP BY Project_ID, Project_Country, Service_Group, Project_Is_Sold, Win_Probability, Project_Is_Chargeable, Project_Client_Contract_Based, Common_Demand_ID, Assignment_ID, 
Role_is_Sold, Role_Sold_Pct, Role_is_Chargeable, Role_Client_Contract_Based, Role_is_Overdue, Number_of_Days_Overdue, Coming_Overdue_Within_7_Days, Role_is_Past_Start_Date, 
Number_of_Days_Past_Start_Date, Role_is_Past_Fulfillment_Date, Days_Past_Fulfillment_Date, Status, Role_Country, Role_Metro_City, Fulfillment_Entity_L1, Fulfillment_Entity_L2, 
Fulfillment_Entity_L3, Fulfillment_Entity_L4, Fulfillment_Entity_L5, Fulfillment_Entity_L6, Role_Priority, Role_Start_Date, Role_Start_Month, Expected_Fulfillment_Date, Role_End_Date, Create_Date, 
Role_Bill_Code_From, Role_Bill_Code_To, Last_Update_Date, Source, Role_is_GCP, Project_Start_Date, Project_End_Date, Project_Opportunity_ID, aa.yearmonth
"""