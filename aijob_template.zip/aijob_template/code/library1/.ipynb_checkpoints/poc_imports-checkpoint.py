# General imports used in POC notebooks

import pandas as pd
pd.set_option('display.max_columns', None)

import numpy as np
import os
import pickle
import yaml
import time
import copy

import matplotlib.pyplot as plt

import seaborn as sns
import csv
import datetime
import glob
import timeit
import re
from dateutil.relativedelta import relativedelta
import logging
from importlib import reload

import sys
sys.path.insert(0, r'..')

from statsmodels.tsa.seasonal import STL, seasonal_decompose
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.stattools import adfuller
# sys.path.append('ATP_9375_Project/AI_Platform/helper-module')

# import pmdarima  # TEMPORARY
# from pmdarima import auto_arima  # TEMPORARY


from sklearn.linear_model import Lasso

from sklearn.metrics import mean_absolute_percentage_error as mape
from sklearn import preprocessing

from google.cloud import bigquery
# from pymlhelper import bqhelper, gcshelper