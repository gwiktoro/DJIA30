from pmdarima.arima import ndiffs, nsdiffs
from statsmodels.tsa.stattools import kpss, adfuller
from statsmodels.regression.linear_model import OLS
from statsmodels.tsa.tsatools import add_trend
from statsmodels.stats.stattools import durbin_watson
from statsmodels.stats.diagnostic import kstest_normal

import re
import pandas as pd
import numpy as np

from sklearn.metrics import mean_absolute_percentage_error as mape
from dateutil.relativedelta import relativedelta

def int_order(serie, alpha=0.05, regression="c", order=0, trace=False):
    """
    Finds the integration order of `serie`. Uses ADF and KPSS tests.
    
    alpha - p-value limit for the tests
    regression - Constant and trend order to include in regression (see statsmodels documentation of adfuller)
    order - order to return if both tests say stationary
    trace - if to print messages
    
    Differentiate until we get a clearly non-stationary time series.
    If both tests say always the same we are fine. If they are contrary, we return reliable = 0.
    """
    res_kpss = kpss(serie, regression=regression)
    res_adf = adfuller(serie, regression=regression)

    if trace:
        print(res_kpss)
        print(res_adf)
    
    # If both tests say nonstationary
    if res_kpss[1] < alpha and res_adf[1] > alpha:
        order, reliable = int_order(serie.diff(1).dropna(), alpha, regression, order+1, trace = trace)
    # If one says stationary (but not both or previous case)
    elif res_kpss[1] < alpha or res_adf[1] > alpha:
        order, reliable = int_order(serie.diff(1).dropna(), alpha, regression, order+1, trace = trace)
        reliable = False
    # If both say stationary we just return the order
    else:
        reliable = True
    # Return the order
    if trace:
        print(f"Order detected:{order}")
    return order, reliable

def related(s1, s2, trace=False):
    """ checks if two series (s1 and s2) are related based on several statistical tests.
        Method devised by Ricardo Garcia
        
        trace - if to print messages
    
    
    """
    print("ADSFASFSF")
    
    d1, rel1 = int_order(s1, alpha = 0.05, trace=trace)
    d2, rel2 = int_order(s2, alpha = 0.05, trace=trace)
    
    if rel1 and rel2 and (d1!=d2 or d1>1 or d2>1):
        if trace:
            print("Different orders. Or orders higher than 1 found.")
        return(False, 0)
    
    aux = add_trend(s2, trend = "ctt", prepend=True, has_constant='add')  # GW 211124 has_constant ensures the number of  columns is the same always. 
    aux.columns = ["const", "trend", "tt", s2.name]
    
    print('s1',s1)
    print('aux',aux)
    results = OLS(s1, aux).fit()
    
    if trace:
        display(results.summary())
    
    ks = kstest_normal(results.resid, dist='norm', pvalmethod='table')
    dws = durbin_watson(results.resid)
    res_order = int_order(results.resid, regression="c")
    rsquared = results.rsquared
    
    print('s2.name:',s2.name)
    print("results.pvalues:",results.pvalues)
        
    if results.pvalues[s2.name] < 0.05 and ks[1] > 0.01 and dws > 1 and dws < 2:
        if rel1 and rel2 and d1==0:
            if trace:
                print("Relationship with stationary series.")
            return(True, rsquared)
        elif rel1 and rel2 and d1==1 and (res_order[0]==0 or res_order[1]==0):
            if trace:
                print("Relationship with I(1) series found and possibly stationary relationship.")
            return(True, rsquared)
        elif rel1 and rel2 and d1==1 and res_order[0]!=0 and res_order[0]!=1:
            if trace:
                print("Relationship with I(1) series found but clearly non-stationary.")
            return(False, 0)
        else:
            if trace:
                print("Relationship with series of unreliable order.")
            return(True, rsquared)            
    else:
        if trace:
            print("No relationship found in OLS or model unreliable.")
        return(False, 0)
    
def get_related_noninv_vars(variables, past_data, target, verbose=True):
    """ Returns a list of tuples with relevant variable name, lag and r2 from OLS fitting with the target variable
        
        variables - list of variable to consider
        past_data - past data for the specific date for which we want the relevant variables to be calculated
        target - name of the target variable
        verbose - if to produce messages to the console
    
    """
    
    
    
    related_noninv_vars = []
    for tested_var in variables:  # relevant_ppd_variables_fte+relevant_avail_variables+relevant_ood_variables:
        if not re.search("_H[0-6]", tested_var): 

            for lag in [1,2,3,6,12]:
                if verbose: 
                    print(tested_var, lag)

                aux = pd.DataFrame([past_data[target], past_data[tested_var].shift(lag)]).T.dropna()
                aux.columns = [target, f"{tested_var}_lag{lag}"]
                aux["Date"] = past_data["Date"]

                re_out, rsquared = related(aux[target], aux[f"{tested_var}_lag{lag}"], trace=False)
                if re_out:
                    related_noninv_vars+=[(f"{tested_var}", lag, rsquared)]
                #print(re_out)

                """
                plt.figure(figsize=(8,6))
                ax=sns.barplot(data=aux, x="Date", y=f"{tested_var}_lag{lag}")
                ax2=ax.twinx() 
                sns.pointplot(data=aux, x="Date", y="Chargeable_FTE", ax=ax2)
                ax.set_xticks(range(len(set(aux["Date"]))))
                ax.set_xticklabels(np.unique(aux["Date"].dt.strftime(date_format='%Y%m')), rotation=90)
                plt.title(f"{tested_var}_lag{lag}")
                ax.set_ylabel(f"{tested_var}_lag{lag}")
                ax2.set_ylabel("Chargeable_FTE")
                plt.show()
                """
    return related_noninv_vars

def remove_coint_exog_vars(related_noninv_vars, past_data, verbose=False):
    """ Removes variables which are cointegrated from related_noninv_vars (typically, comming from get_related_noninv_vars function)
    
        return a selection of non-cross-cointegrated variables from related_noninv_vars 
    """
    
    sorted_related_noninv_vars = sorted(related_noninv_vars, key=lambda x:x[2], reverse=True)
    
    ret = []
    for var, lag, r2 in sorted_related_noninv_vars:
        for ret_var, ret_lag, ret_r2 in ret:
            
            aux = pd.DataFrame([past_data[var].shift(lag), past_data[ret_var].shift(ret_lag)]).T.dropna()
            aux.columns = [f"{var}_lag{lag}", f"{ret_var}_lag{ret_lag}"]
            aux["Date"] = past_data["Date"]

            re_out, rsquared = related(aux[f"{var}_lag{lag}"], aux[f"{ret_var}_lag{ret_lag}"], trace=False)
            
            if verbose:
                print(var, lag, r2, ret_var, ret_lag, ret_r2, re_out, rsquared)
            
            if re_out:
                break
        else:
            ret.append((var, lag, r2))
            if verbose:
                print("RET:",ret)
    return ret
            
def get_coint_matrix_df(related_noninv_vars, past_data):
    
    """ Calculates a matrix of cointegrations between variables in related_noninv_vars """
    
    coint_matrix =[]
    for tested_var1, lag1, rsquared_target in related_noninv_vars:
        coint_row = []
        for tested_var2, lag2, rsquared_target in related_noninv_vars:

            #print(f"{tested_var1}_lag{lag1}", f"{tested_var2}_lag{lag2}")
            if f"{tested_var1}_lag{lag1}" == f"{tested_var2}_lag{lag2}":
                coint_row += [True]
                #print(True)
                continue

            aux = pd.DataFrame([past_data[tested_var1].shift(lag1), past_data[tested_var2].shift(lag2)]).T.dropna()
            aux.columns = [f"{tested_var1}_lag{lag1}", f"{tested_var2}_lag{lag2}"]
            aux["Date"] = past_data["Date"]

            #display(aux)
            re_out, rsquared = related(aux[f"{tested_var1}_lag{lag1}"], aux[f"{tested_var2}_lag{lag2}"], trace=False)
            if re_out:
                coint_row += [True]
            else:
                coint_row += [False]
            #print(re_out)
        coint_matrix += [coint_row] 

    coint_matrix_arr = np.array(coint_matrix)

    coint_matrix_arr = (coint_matrix_arr) & (coint_matrix_arr.T)

    coint_matrix_df = pd.DataFrame(np.array(coint_matrix_arr))

    coint_matrix_df.columns = [f"{x[0]}_lag{x[1]}" for x in related_noninv_vars]

    coint_matrix_df.index = [f"{x[0]}_lag{x[1]}" for x in related_noninv_vars]
    
    return coint_matrix_df 

def median_ensemble_mape(df_test_with_preds_all_fte):
    """Calculates the MAPE value for median ensemble based on precalculated input df_test_with_preds_all_fte (see notebooks for details)"""
    
    df_ensemble_median = df_test_with_preds_all_fte.copy()
    #df_ensemble = df_ensemble[(df_ensemble["lag"].isin([6, 12])) & (df_ensemble["extra_var"]!="Now_Available")]
    df_ensemble_median = df_ensemble_median.groupby(by=["pred_time", "horizon", "ds"])[["y", "yhat"]].median().reset_index()
    df_ensemble_median["error"] = abs(df_ensemble_median["y"] - df_ensemble_median["yhat"]) / df_ensemble_median["y"] * 100
    return mape(df_ensemble_median["y"], df_ensemble_median["yhat"])*100

def mean_ensemble_mape(df_test_with_preds_all_fte):
    """Calculates the MAPE value for mean ensemble based on precalculated input df_test_with_preds_all_fte (see notebooks for details)"""
    df_ensemble_avg = df_test_with_preds_all_fte.copy()
    df_ensemble_avg = df_ensemble_avg.groupby(by=["pred_time", "horizon", "ds"])[["y", "yhat"]].mean().reset_index()
    df_ensemble_avg["error"] = abs(df_ensemble_avg["y"] - df_ensemble_avg["yhat"]) / df_ensemble_avg["y"] * 100
    return mape(df_ensemble_avg["y"], df_ensemble_avg["yhat"])*100

def softmax_base(arr, base=0.99):
    """ applyies softmax to arr with an arbitrary base"""
    return np.power(np.full(len(arr), base), arr) / sum(np.power(np.full(len(arr), base), arr))

def weighted_mean_ensemble_mape(df_test_with_preds_all_fte):
    """Calculates the MAPE value for weighted mean ensemble based on precalculated input df_test_with_preds_all_fte (see notebooks for details)"""
    
    df_aux_3_list = []
    for horizon in range(1, 7):
        df_horizon = df_test_with_preds_all_fte[df_test_with_preds_all_fte["horizon"]==horizon][["pred_time", "horizon", "ds", "extra_var", "lag", "y", "yhat", "error"]].copy()

        for i, pred_month in enumerate(np.unique(df_horizon["pred_time"])):

            df_h_prev_data = df_horizon[(df_horizon["ds"]<=pred_month) & (df_horizon["ds"]>pd.to_datetime(pred_month) - relativedelta(months=+12))].copy()
            baseline_no_exog_horizon_error = df_h_prev_data[df_h_prev_data["extra_var"]=="NO_EXOG"]["error"].mean()

            if len(np.unique(df_h_prev_data["ds"]))<4:
                #df_vars = df_horizon[df_horizon["extra_var"]=="NO_EXOG"][["extra_var", "lag"]].drop_duplicates(keep='first')
                df_vars = df_horizon[["extra_var", "lag"]].drop_duplicates(keep='first')
                df_vars["weights"] = 1/len(df_vars)
            else:
                df_aux = df_h_prev_data.groupby(by=["extra_var", "lag"])["error"].mean().reset_index().sort_values("error", ascending=True).reset_index(drop=True)
                #df_improving_vars = df_aux[(df_aux["error"]<=baseline_no_exog_horizon_error)].head(40)
                #df_minimum = df_aux.iloc[len(df_improving_vars):10]
                #df_vars = pd.concat([df_improving_vars, df_minimum], axis=0)
                df_vars = df_aux[["extra_var", "lag", "error"]].head(20).drop_duplicates(keep='first')
                df_vars["weights"] = softmax_base(df_vars["error"], 0.9)
                #df_vars["weights"] = 1/len(df_vars)
                df_vars = df_vars.drop("error", axis=1)  

            #print(horizon, pred_month)
            #display(df_vars)

            df_aux_2 = df_horizon[df_horizon["pred_time"]==pred_month].copy()
            df_aux_3 = df_vars.merge(df_aux_2, on=["extra_var", "lag"], how="left")

            #display(df_aux_3)

            df_aux_3_list += [df_aux_3]
            
    df_ensemble_wghtavg = pd.concat(df_aux_3_list)
    
    df_ensemble_wghtavg["yhat_w"] =  df_ensemble_wghtavg["yhat"] * df_ensemble_wghtavg["weights"]
    df_ensemble_wghtavg = df_ensemble_wghtavg.groupby(by=["pred_time", "horizon", "ds"])[["y", "yhat", "yhat_w", "weights"]].agg(y=("y", "mean"), yhat=("yhat_w", "sum")).reset_index()
    df_ensemble_wghtavg["error"] = abs(df_ensemble_wghtavg["y"] - df_ensemble_wghtavg["yhat"]) / df_ensemble_wghtavg["y"] * 100
    df_ensemble_wghtavg["horizon"] = df_ensemble_wghtavg["horizon"].astype("int64")
    return mape(df_ensemble_wghtavg["y"], df_ensemble_wghtavg["yhat"])*100

def months_compare(df_grouped_final, df_test_with_preds_all_fte, rel_vars, target):
    """ compares MAPEs for different ensembles, months and variable selection algorithms 
    
        Four numbers for each model+month represent MAPEs for
          1. all variables
          2. anly relevant variables (all lags included)
          3. only relevant variables and relevant lags
          4. relevant variables and their lags with cointegrated variables removed
    
    """

    df_all_vars = df_test_with_preds_all_fte.copy()
    
    print("ALL  names_only names+lags  names+lags-cointegrated")

    for month in df_grouped_final["mapping_yearmonth"].unique():
        past_data = df_grouped_final[df_grouped_final["mapping_yearmonth"]==month] 
        
        
        related_noninv_vars = get_related_noninv_vars(rel_vars, past_data, target, verbose=False)
#         new_rel_vars = [x[0] for x in related_noninv_vars]

        df_new_vars = df_all_vars.merge(pd.DataFrame(related_noninv_vars, columns=['extra_var','lag','r2']), on=['extra_var','lag'], how='inner')
#         df_new_vars = df_all_vars[df_all_vars.extra_var.isin(new_rel_vars)]

        df_new_nolags_vars = df_all_vars.merge(pd.DataFrame(related_noninv_vars, columns=['extra_var','lag_unimportant','r2'])[["extra_var"]].drop_duplicates(), on=['extra_var'], how='inner')
#         display(df_new_nolags_vars.head())
        
        picked_noninv_vars = remove_coint_exog_vars(related_noninv_vars, past_data)
#         new_picked_vars = [x[0] for x in picked_nonint_vars]
        df_picked_vars = df_all_vars.merge(pd.DataFrame(picked_noninv_vars, columns=['extra_var','lag','r2']), on=['extra_var','lag'], how='inner')
        
        print(month)
        print("median", median_ensemble_mape(df_all_vars), median_ensemble_mape(df_new_nolags_vars), median_ensemble_mape(df_new_vars), median_ensemble_mape(df_picked_vars))
        print("mean", mean_ensemble_mape(df_all_vars), mean_ensemble_mape(df_new_nolags_vars), mean_ensemble_mape(df_new_vars), mean_ensemble_mape(df_picked_vars))
        print("weighted_mean", weighted_mean_ensemble_mape(df_all_vars), weighted_mean_ensemble_mape(df_new_nolags_vars), weighted_mean_ensemble_mape(df_new_vars), weighted_mean_ensemble_mape(df_picked_vars))
        print()