import pandas as pd
import numpy as np

import re

from sklearn.linear_model import Lasso

from cdplib.poc_variables import LB, Availability, OOD, OM


# DEFINITIONS OF FUNCTIONS USED TO PREPARE DATA FOR MODELING
# Each of these functions also return a list with the names of the relevant variables in order to keep track of them. 

# The availability variables, they refer to when the employee is going to leave a project, or if it is booked for another one, how many people are benched per intersection ... 


def create_avail_variables(df):

    # Aux dates
    df['First_Available_Date'] = pd.to_datetime(df['First_Available_Date'], format='%Y-%m-%d').dt.tz_localize(None)
    df['First_Available_Date_M'] = pd.to_datetime(df['First_Available_Date'].dt.strftime(date_format='%Y%m'), format='%Y%m')
    df['Current_Calendar_Roll_Off_Confirmed_Date'] = df['Current_Calendar_Roll_Off_Confirmed_Date'].dt.tz_localize(None)
    df['Current_Calendar_Roll_Off_Confirmed_Date_M'] = pd.to_datetime(df['Current_Calendar_Roll_Off_Confirmed_Date'].dt.strftime(date_format='%Y%m'), format='%Y%m')
    df['Current_Calendar_End_Date'] = df['Current_Calendar_End_Date'].dt.tz_localize(None)
    df['Current_Calendar_End_Date_M'] = pd.to_datetime(df['Current_Calendar_End_Date'].dt.strftime(date_format='%Y%m'), format='%Y%m')

#     df["Months_to_first_avail"] = (df['First_Available_Date'].dt.to_period('M').astype(int)-df['Date'].dt.to_period('M').astype(int))
#     df["Months_to_end_project"] = (df['Current_Calendar_End_Date'].dt.to_period('M').astype(int)-df['Date'].dt.to_period('M').astype(int))
    df["Months_to_first_avail"] = (df['First_Available_Date'].dt.to_period('M').view(int)-df['Date'].dt.to_period('M').view(int))
    df["Months_to_end_project"] = (df['Current_Calendar_End_Date'].dt.to_period('M').view(int)-df['Date'].dt.to_period('M').view(int))

    # Available Resources
    df["Total_Bench"] = ((df["Availability_Status"]=="Available") & (df["Availability_Detail"]=="Now Available") & (df["First_Available_Date_M"]<=df["Date"])).astype(int)
    df["Aged_Bench"] = ((df["Availability_Status"]=="Available") & (df["Availability_Detail"]=="Now Available") & (df["Now_Available_Category"].isin(["Resource Now Available >12 Weeks", "Resource Now Available 5-12 Weeks"])) & (df["First_Available_Date_M"]<=df["Date"])).astype(int)
    df["Recent_Bench"] = ((df["Availability_Status"]=="Available") & (df["Availability_Detail"]=="Now Available") & ~(df["Now_Available_Category"].isin(["Resource Now Available >12 Weeks", "Resource Now Available 5-12 Weeks"])) & (df["First_Available_Date_M"]<=df["Date"])).astype(int)

    # BTP / BTCP / BTNCP
    df["Booked_To_Project"] = (df["Current_Calendar_Entry"]=="Booked To A Project").astype(int)
    df["Booked_To_Chargeable_Project"] = ((df["Current_Calendar_Entry"]=="Booked To A Project") & (df["Current_Project_Is_Chargeable"]=="Yes")).astype(int)
    df["Booked_To_Non_Chargeable_Project"] = ((df["Current_Calendar_Entry"]=="Booked To A Project") & (df["Current_Project_Is_Chargeable"]!="Yes")).astype(int)

    avail_vars = ["Total_Bench", "Aged_Bench", "Recent_Bench", "Booked_To_Project", "Booked_To_Chargeable_Project", "Booked_To_Non_Chargeable_Project"]
    
    # For all future horizons
    for h in range(1,7):
        # Rolled off prev month
        df["BTCP_Confirmed_RollOff_PrevMonth_H{}".format(h)] = ((df["Booked_To_Chargeable_Project"]==True) & (df["Current_Calendar_Roll_Off_Confirmed"]=="Y") & (df["Months_to_end_project"]==h-1)).astype(int)
        # Rolled off times the amount of days worked
        df["BTCP_Confirmed_RollOff_PrevMonth_Loss_H{}".format(h)] = df["BTCP_Confirmed_RollOff_PrevMonth_H{}".format(h)] * ((df['Current_Calendar_End_Date']-df['Date']).dt.days.fillna(-1).astype(int) / df['Current_Calendar_End_Date'].dt.days_in_month.fillna(-1).astype(int))
        # Probably rolling off that month
        df["BTCP_Confirmed_RollOff_ThatMonth_H{}".format(h)] = ((df["Booked_To_Chargeable_Project"]==True) & (df["Current_Calendar_Roll_Off_Confirmed"]=="Y") & (df["Months_to_end_project"]==h)).astype(int) 
        # Rolling off times the amount of days not worked
        df["BTCP_Confirmed_RollOff_ThatMonth_Loss_H{}".format(h)] = df["BTCP_Confirmed_RollOff_ThatMonth_H{}".format(h)] * ((df['Current_Calendar_End_Date'].dt.days_in_month.fillna(-1).astype(int) - df['Current_Calendar_End_Date'].dt.day.fillna(-1).astype(int)) / df['Current_Calendar_End_Date'].dt.days_in_month.fillna(-1).astype(int))
        # Expected loss
        df["Confirmed_Expected_Loss_H{}".format(h)] = df["BTCP_Confirmed_RollOff_PrevMonth_Loss_H{}".format(h)] + df["BTCP_Confirmed_RollOff_ThatMonth_Loss_H{}".format(h)]
        avail_vars+=["BTCP_Confirmed_RollOff_PrevMonth_H{}".format(h), "BTCP_Confirmed_RollOff_PrevMonth_Loss_H{}".format(h),
                     "BTCP_Confirmed_RollOff_ThatMonth_H{}".format(h), "BTCP_Confirmed_RollOff_ThatMonth_Loss_H{}".format(h), "Confirmed_Expected_Loss_H{}".format(h)]

    # For near horizons only
    for h in range(1,7):
        # Rolled off prev month
        df["BTCP_Unconfirmed_RollOff_PrevMonth_H{}".format(h)] = ((df["Booked_To_Chargeable_Project"]==True) & (df["Current_Calendar_Roll_Off_Confirmed"]!="Y") & (df["Months_to_end_project"]==h-1)).astype(int)
        # Rolled off times the amount of days worked
        df["BTCP_Unconfirmed_RollOff_PrevMonth_Loss_H{}".format(h)] = df["BTCP_Unconfirmed_RollOff_PrevMonth_H{}".format(h)] * ((df['Current_Calendar_End_Date']-df['Date']).dt.days.fillna(-1).astype(int) / df['Current_Calendar_End_Date'].dt.days_in_month.fillna(-1).astype(int))
        # Probably rolling off that month
        df["BTCP_Unconfirmed_RollOff_ThatMonth_H{}".format(h)] = ((df["Booked_To_Chargeable_Project"]==True) & (df["Current_Calendar_Roll_Off_Confirmed"]!="Y") & (df["Months_to_end_project"]==h)).astype(int)
        # Rolling off times the amount of days not worked
        df["BTCP_Unconfirmed_RollOff_ThatMonth_Loss_H{}".format(h)] = df["BTCP_Unconfirmed_RollOff_ThatMonth_H{}".format(h)] * ((df['Current_Calendar_End_Date'].dt.days_in_month.fillna(-1).astype(int) - df['Current_Calendar_End_Date'].dt.day.fillna(-1).astype(int)) / df['Current_Calendar_End_Date'].dt.days_in_month.fillna(-1).astype(int))
        # Expected loss
        df["Unconfirmed_Expected_Loss_H{}".format(h)] = df["BTCP_Unconfirmed_RollOff_PrevMonth_Loss_H{}".format(h)] + df["BTCP_Unconfirmed_RollOff_ThatMonth_Loss_H{}".format(h)] 
        avail_vars+=["BTCP_Unconfirmed_RollOff_PrevMonth_H{}".format(h), "BTCP_Unconfirmed_RollOff_PrevMonth_Loss_H{}".format(h),
                     "BTCP_Unconfirmed_RollOff_ThatMonth_H{}".format(h), "BTCP_Unconfirmed_RollOff_ThatMonth_Loss_H{}".format(h), "Unconfirmed_Expected_Loss_H{}".format(h)]

    return df, avail_vars




# The LB variables are the ones that contain the productivity and chargeability data. 
# Chrg_Time_Total_FTEs is going to be referred as Chargeable_FTE and is our target to predict. 
# Other interesting variables such as Overtime, Standard Available Hours, or vacation time can be created using this dataset.

def create_LB_variables(df):
    df.loc[df['Chrg_Time_Total']==0, 'Standard_Available_Hrs'] = df["Total_Reported_Time"] - df["Non_Chrg_Time_APA"]
    df.loc[df['Chrg_Time_Total']!=0, 'Standard_Available_Hrs'] = df["Chrg_Time_Total"]/df["Chrg_Time_Total_FTEs"]
    df.loc[df['Chrg_Time_Total']==0, 'Overtime_Hrs'] = 0
    df.loc[df['Chrg_Time_Total']!=0, 'Overtime_Hrs'] =  + df["Chrg_Time_Total"] - df["Non_Chrg_Time_APA"] - df["Standard_Available_Hrs"]
    df.loc[df['Overtime_Hrs']<0, 'Overtime_Hrs'] =  0
    df.replace([np.inf, -np.inf], 0,inplace=True)
    df["Non_Chrg_Time_Total_FTE"]=df["Non_Chrg_Time_Total"]/df['Total_Reported_Time'].where(df['Total_Reported_Time']>0, np.inf)
    df["Non_Chrg_Time_Bus_Dev_FTE"]=df["Non_Chrg_Time_Bus_Dev"]/df['Total_Reported_Time'].where(df['Total_Reported_Time']>0, np.inf)
    df["Non_Chrg_Time_Mrkt_Dev_and_Off_Dev_Main_FTE"]=df["Non_Chrg_Time_Mrkt_Dev_and_Off_Dev_Main"]/df['Total_Reported_Time'].where(df['Total_Reported_Time']>0, np.inf)
    df["Non_Chrg_Time_Cap_Infra_Dev_FTE"]=df["Non_Chrg_Time_Cap_Infra_Dev"]/df['Total_Reported_Time'].where(df['Total_Reported_Time']>0, np.inf)
    df["Non_Chrg_Time_M_O_FTE"]=df["Non_Chrg_Time_M_O"]/df['Total_Reported_Time'].where(df['Total_Reported_Time']>0, np.inf)
    df["Non_Chrg_Time_Prof_Dev_Recr_FTE"]=df["Non_Chrg_Time_Prof_Dev_Recr"]/df['Total_Reported_Time'].where(df['Total_Reported_Time']>0, np.inf)
    df["Non_Chrg_Time_APA_FTE"]=df["Non_Chrg_Time_APA"]/df['Total_Reported_Time'].where(df['Total_Reported_Time']>0, np.inf)
    df["Standard_Available_Hrs_FTE"]=df["Standard_Available_Hrs"]/df['Total_Reported_Time'].where(df['Total_Reported_Time']>0, np.inf)
    df["Overtime_Hrs_FTE"]=df["Overtime_Hrs"]/df['Total_Reported_Time'].where(df['Total_Reported_Time']>0, np.inf)
    df.rename(columns={"Chrg_Time_Total_FTEs":"Chargeable_FTE"},inplace=True)
    
    
    
    LB_FTE = ['Non_Chrg_Time_Total_FTE',
       'Non_Chrg_Time_Bus_Dev_FTE',
       'Non_Chrg_Time_Mrkt_Dev_and_Off_Dev_Main_FTE',
       'Non_Chrg_Time_Cap_Infra_Dev_FTE', 'Non_Chrg_Time_M_O_FTE',
       'Non_Chrg_Time_Prof_Dev_Recr_FTE', 'Non_Chrg_Time_APA_FTE',
       'Standard_Available_Hrs_FTE', 'Overtime_Hrs_FTE']
    
    return df,LB_FTE



# Finally the OOD data is referred to an intersection, it needs to be grouped and looked in a monthly level. 
# Here we are defined when a project is sold, unsold, the probabilities of it being sold, if it is chargeable, Overdue, confirming ... 
# then it is weighted by the percentege of demand that can be satisfied by our goal intersection and aggregated by month and it is ready to ingest to the final dataframe.

def create_ood_variables(df):
    
    # Aux dates
    df['Role_Start_Date'] = pd.to_datetime(df['Role_Start_Date'], format='%Y-%m-%d')
    df['Role_Start_Date_M'] = pd.to_datetime(df['Role_Start_Date'].dt.strftime(date_format='%Y%m'), format='%Y%m')
    
#     df["Months_to_start_role"] = (df['Role_Start_Date'].dt.to_period('M').astype(int)-df['Date'].dt.to_period('M').astype(int))
    df["Months_to_start_role"] = (df['Role_Start_Date'].dt.to_period('M').view(int)-df['Date'].dt.to_period('M').view(int))


    # Open Roles
#     df["Open"] = ((df_ood["Number_of_Days_Past_Start_Date"]<100) | (df_ood["Number_of_Days_Past_Start_Date"].isna())) * df["pct_intersection"]  # FIXME#     
    df["Open"] = ((df["Number_of_Days_Past_Start_Date"]<100) | (df["Number_of_Days_Past_Start_Date"].isna())) * df["pct_intersection"] 

    df["Sold"] = ((df["Open"]!=0) & (df["Role_is_Sold"]=="Yes")) * df["pct_intersection"]
    df["Sold_Chargeable"] = ((df["Sold"]!=0) & (df["Role_is_Chargeable"]=="Yes")) * df["pct_intersection"] 
    df["Unsold"] = ((df["Open"]!=0) & (df["Role_is_Sold"]!="Yes")) * df["pct_intersection"]
    df["Unsold_Chargeable"] = ((df["Unsold"]!=0) & (df["Role_is_Chargeable"]=="Yes")) * df["pct_intersection"] 
    df["Unsold_Prob"] = (df["Unsold"] * df["Role_Sold_Pct"] / 100) * df["pct_intersection"]
    df["Unsold_Chargeable_Prob"] = (df["Unsold_Chargeable"] * df["Role_Sold_Pct"] / 100) * df["pct_intersection"]
    df["Sold_Unsold_Chargeable_Prob"] = (df["Sold_Chargeable"] + df["Unsold_Chargeable_Prob"]) * df["pct_intersection"]
    df["Overdue"] = ((df["Open"]!=0) & (df["Role_is_Overdue"]=="Yes") )* df["pct_intersection"] 
    df["Confirming"] =( (df["Open"]!=0) & (df["Status"]=="Open - Confirming Candidate") )* df["pct_intersection"]

    ood_vars = ["Open", "Sold", "Sold_Chargeable", "Unsold", "Unsold_Chargeable", "Unsold_Prob", "Unsold_Chargeable_Prob", "Sold_Unsold_Chargeable_Prob", "Overdue", "Confirming"]

    # For all future horizons
    for h in range(1,7):
        # Probably starting that month (sold + Unsold)
        df["Sold_Chargeable_StartingMonth_H{}".format(h)] = ((df["Sold_Chargeable"]!=0) & (df["Months_to_start_role"]==h)) * df["pct_intersection"] 
        df["Unsold_Chargeable_StartingMonth_H{}".format(h)] = ((df["Unsold_Chargeable"]!=0) & (df["Months_to_start_role"]==h)) * df["pct_intersection"] 
        df["Unsold_Chargeable_Prob_StartingMonth_H{}".format(h)] = (df["Unsold_Chargeable_StartingMonth_H{}".format(h)] * df["Role_Sold_Pct"] / 100 )* df["pct_intersection"]
        df["Sold_Unsold_StartingMonth_H{}".format(h)] = (df["Sold_Chargeable_StartingMonth_H{}".format(h)] + df["Unsold_Chargeable_Prob_StartingMonth_H{}".format(h)] )* df["pct_intersection"]
        df["Confirming_StartingMonth_H{}".format(h)] = ((df["Confirming"]!=0) & (df["Months_to_start_role"]==h)) * df["pct_intersection"] 
        ood_vars+=["Sold_Chargeable_StartingMonth_H{}".format(h), "Unsold_Chargeable_Prob_StartingMonth_H{}".format(h), "Sold_Unsold_StartingMonth_H{}".format(h), "Confirming_StartingMonth_H{}".format(h)]

    return df, ood_vars

def preprocess_ood(df):

    # Create Dates column    
    df['Date'] = pd.to_datetime(df['yearmonth'], format='%Y%m')
    
    # Create OOD variables
    df, relevant_ood_variables = create_ood_variables(df)
    
    # Group data per month
    aggr_levels = ["Date", "yearmonth"]
    df_grouped = df[aggr_levels+relevant_ood_variables].groupby(by=aggr_levels).sum().reset_index()
    
    return df_grouped, relevant_ood_variables

#

def get_related_inv_vars(relevant_variables, past_data, target, verbose=False):
    
    vars_h = {}
    for tested_var in relevant_variables:
        if re.search(f"_H[0-6]", tested_var): 
            h = int(tested_var[-1])
            try:
                vars_h[h] = vars_h[h] + [tested_var]
            except:
                vars_h[h] = [tested_var]    
    inv_vars = []
    for h in range(1,7):
        aux_fit = past_data.copy()
        aux_fit[f"Chargeable_FTE_D{h}"] = aux_fit[target].shift(-h) - aux_fit[target].shift(-(h-1))
        aux_fit = aux_fit[[v for v in vars_h[h]] + [f"Chargeable_FTE_D{h}"]].dropna()

 

        clf = Lasso(fit_intercept=True)

 

        #display(aux.iloc[:,:-1])
        #display(aux.iloc[:,-1])

 

        clf.fit(aux_fit.iloc[:,:-1], aux_fit.iloc[:,-1])

 

        #print(clf.score(aux_fit.iloc[:,:-1], aux_fit.iloc[:,-1]))
        #print(clf.coef_)

 

        past_data[f"Chargeable_FTE_D{h}_APROXIMATION"] = clf.predict(past_data[[v for v in vars_h[h]]])
        
        inv_vars += [(f"Chargeable_FTE_D{h}_APROXIMATION", h, 1)]
        #display(past_data[[f"Chargeable_FTE_D{h}", f"Chargeable_FTE_D{h}_APROXIMATION"]].corr())
    
    return inv_vars, past_data


def DataSource(row):
    if row["extra_var"] in LB:
        return "LB"
    elif row["extra_var"] in Availability:
        return "Availability"
    elif row["extra_var"] in OOD:
        return "OOD"
    elif 'APROXIMATION' in row['extra_var']:
        return "inventory"
    elif row['extra_var'] in OM:
        return 'OM'
    else:
        return "Time Series"