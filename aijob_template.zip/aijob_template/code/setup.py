
# creating package for AI JOBS environment

from setuptools import find_packages
from setuptools import setup

# specify required packages and version 
REQUIRED_PACKAGES = ['google-cloud-bigquery', 'google-cloud-bigquery-storage','scikit-learn>=0.24','numpy==1.19.5','pandas==1.3','statsmodels==0.12.2','pmdarima']
# scikit-learn is to old by default and we need 0.24 at least
# numpy 1.19.5 is necessary for pandas binding with pyarrow (to work with bigquery). The later version 1.20 doesn't work well with pyarrow
# pandas - not sure if necessary
# pmdarima - necessary for poc model

setup(
  name='chargeable-demand-train-package',
  version='0.1',
  install_requires=REQUIRED_PACKAGES,
  packages=find_packages(),  # automatically find suporting modules like cdplib
  description='A deployment package for training on Cloud ML Engine.',
#  scripts = ['job/main.py','job/config.yml','job/config.py',] , #'job/bq.py' # This is not necessary
  package_data = {'job' : ["*.yml", "job/*"] }  # this is necessary
)
